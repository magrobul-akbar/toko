// sidebar collapse
const btnToggle = document.querySelector(".btn-toggle");
const sidebar = document.querySelector(".sidebar");
const mainContent = document.querySelector(".main-content");

btnToggle.addEventListener("click", function (e) {
  e.preventDefault();
  sidebar.classList.toggle("active");
  mainContent.classList.toggle("active");
});
