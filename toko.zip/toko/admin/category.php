<?php 
require_once __DIR__ . '/admin.php';

if( $act == 'edit' ) {
    if( ! isset( $_GET['id'] ) || empty( $_GET['id'] ) ) {
        header('location: category.php');
        exit;
    }

    if( is_null( $category ) ) {
        header('location: category.php');
        exit;
    }
}

$page_title = 'Kategori';
$page_active = 'kategori';
require_once __DIR__ . '/header.php';
?>
<!-- content -->
<section class="content">

    <div class="row g-3">

        <div class="col-lg-4">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <form action="category.php?post_type=category<?= ( $post_type == 'category' && $act == 'edit' ) ? '&act=edit&id=' . $category->id : '&act=create'; ?>" method="POST">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= ( $post_type == 'category' && $act == 'edit' ) ? $category->name : ''; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm" name="save">Simpan</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- table category -->
        <div class="col-lg-8">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Nama</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if( count( $categories ) ) :
                                foreach( $categories as $category ) :
                            ?>
                            <tr>
                                <td><?= $category->name; ?></td>
                                <td>
                                    <?php 
                                    if( $post_type == 'category' && $act == 'edit' ) :
                                    ?>
                                    <a href="category.php" class="btn btn-warning btn-sm">
                                        <i class="bi bi-x me-1"></i>Cancel
                                    </a>
                                        

                                    <?php 
                                    else :
                                    ?>
                                    <a href="category.php?post_type=category&act=edit&id=<?= $category->id; ?>" class="btn btn-warning btn-sm">
                                        <i class="bi bi-pencil me-1"></i>Edit
                                    </a>
                                    <form action="category.php?post_type=category" method="POST" class="d-inline-block">
                                        <input type="hidden" name="category_id" value="<?= $category->id; ?>">
                                        <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Kategori <?= $category->name; ?> akan dihapus!')">
                                            <i class="bi bi-trash me-1"></i>Hapus
                                        </button>
                                    </form>
                                    <?php 
                                    endif;
                                    ?>
                                </td>
                            </tr>
                            <?php 
                                endforeach;
                            else :
                            ?>
                            <tr>
                                <td colspan="2" align="center">Kategori tidak ditemukan</td>
                            </tr>
                            <?php 
                            endif;
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- end table category -->

    </div>

</section>
<!-- end content -->   
<?php 
require_once __DIR__ . '/footer.php';
?>