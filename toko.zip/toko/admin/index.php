<?php 
require_once __DIR__ . '/admin.php';

$page_title = 'Dashboard';
$page_active = 'dashboard';
require_once __DIR__ . '/header.php';
?>

<!-- content -->
<section class="content">

    <div class="row g-3">

        <!-- welcome -->
        <div class="col-12">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <h5 class="card-title">Selamat Username Datang di TOKO</h5>
                    <p class="card-text">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eaque, necessitatibus eius aut id nobis commodi voluptatum aliquam facere perspiciatis nostrum voluptatibus debitis suscipit eos velit, minima ratione error, dolorum quibusdam!
                    </p>
                </div>
            </div>
        </div>
        <!-- end welcome -->

        <!-- pengguna -->
        <div class="col-md-4">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <h5 class="card-title"><i class="bi bi-people me-1"></i>Pengguna</h5>
                    <p class="card-text">
                        200
                    </p>
                </div>
            </div>
        </div>
        <!-- end pengguna -->

        <!-- kategori -->
        <div class="col-md-4">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <h5 class="card-title"><i class="bi bi-list-ul me-1"></i>Kategori</h5>
                    <p class="card-text">
                        <?= number_format( count( $categories ), 0, ',', '.' ); ?>
                    </p>
                </div>
            </div>
        </div>
        <!-- end kategori -->

        <!-- produk -->
        <div class="col-md-4">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <h5 class="card-title"><i class="bi bi-list-ul me-1"></i>Produk</h5>
                    <p class="card-text">
                        <?= number_format( count( $products ), 0, ',', '.' ); ?>
                    </p>
                </div>
            </div>
        </div>
        <!-- end produk -->

        <!-- produk stok masuk -->
        <div class="col-md-4">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <h5 class="card-title"><i class="bi bi-list-ul me-1"></i>Stock Masuk</h5>
                    <p class="card-text">
                        <?= number_format( count( $products_stock_in ), 0, ',', '.' ); ?>
                    </p>
                </div>
            </div>
        </div>
        <!-- end produk stok masuk -->

        <!-- pengunjung -->
        <div class="col-md-4">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <h5 class="card-title"><i class="bi bi-eye me-1"></i>Pengunjung</h5>
                    <p class="card-text">
                        2.000
                    </p>
                </div>
            </div>
        </div>
        <!-- end pengunjung -->

        <!-- pesanan -->
        <div class="col-md-4">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <h5 class="card-title"><i class="bi bi-chat-dots me-1"></i>Pesanan</h5>
                    <p class="card-text">
                        24
                    </p>
                </div>
            </div>
        </div>
        <!-- end pesanan -->

    </div>

</section>
<!-- end content -->        

<?php 
require_once __DIR__ . '/footer.php';
?>