<?php
require_once __DIR__ . '/admin.php';

$page_title = 'Stock Masuk';
$page_active = 'stock-in';
require_once __DIR__ . '/header.php';
?>
<!-- content -->
<section class="content">

    <div class="row g-3">

        <div class="col-lg-4">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <form action="product-stock-in.php?post_type=product-stock-in&act=create" method="POST">
                		<div class="mb-3">
                            <label for="product_id" class="form-label">Produk</label>
                            <select name="product_id" id="product_id" class="form-select" required>
                            	<option value="">Pilih Produk</option>
                            	<?php 
                        		if( count( $products ) ) :
                        			foreach( $products as $product ) :
                            	?>
                            	<option value="<?= $product->id; ?>"><?= $product->name; ?></option>
                            	<?php 
                            		endforeach;
                            	else :
                            	?>
                            	<option value="">Produk tidak ditemukan</option>
                            	<?php 
                            	endif;
                            	?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="stock" class="form-label">Jumlah</label>
                            <input type="number" class="form-control" id="stock" name="stock" min="1" required>
                        </div>

                        <div class="mb-3">
                            <label for="date_of_entry" class="form-label">Tanggal Masuk</label>
                            <input type="date" class="form-control" id="date_of_entry" name="date_of_entry" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm" name="save">Simpan</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- table product -->
        <div class="col-lg-8">
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Nama</th>
                                <th scope="col">Jumlah</th>
                                <th scope="col">Tanggal Masuk</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if( count( $products_stock_in ) ) :
                                foreach( $products_stock_in as $product ) :
                            ?>
                            <tr>
                                <td><?= $product->name; ?></td>
                                <td><?= number_format( $product->stock, 0, ',', '.' ); ?></td>
                                <td><?= date( 'Y-m-d', strtotime( $product->date_of_entry ) ); ?></td>
                                <td>
                                    <form action="product-stock-in.php?post_type=product-stock-in" method="POST" class="d-inline-block">
                                        <input type="hidden" name="product_stock_in_id" value="<?= $product->id; ?>">
                                        <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Stock untuk produk <?= $product->name; ?> akan dihapus sebanyak <?= $product->stock; ?>!')">
                                            <i class="bi bi-trash me-1"></i>Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php 
                                endforeach;
                            else :
                            ?>
                            <tr>
                                <td colspan="4" align="center">Produk tidak ditemukan</td>
                            </tr>
                            <?php 
                            endif;
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- end table product -->

    </div>

</section>
<!-- end content --> 
<?php 
require_once __DIR__ . '/footer.php';
?>