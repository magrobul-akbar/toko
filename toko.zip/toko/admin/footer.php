</div>

            <!-- footer -->
            <footer class="footer">
                <div class="d-flex justify-content-center align-items-center pt-2">
                    <p class="p-0">Copyright &copy; <span class="text-primary">Magrobul Akbar</span> - <?= date('Y'); ?></p>
                </div>
            </footer>
            <!-- end footer -->

        </main>
        <!-- end main content -->
    </div>
    <!-- end wrapper -->
    
    <!-- bootstrap bundle js -->
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- admin js -->
    <script src="../assets/js/admin.js"></script>
</body>
</html>