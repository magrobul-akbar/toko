<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title; ?> - TOKO</title>

    <!-- bootstrap css -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">

    <!-- bootstrap icons -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/font/bootstrap-icons.css">

    <!-- admin css -->
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- wrapper -->
    <div class="wrapper">

        <aside class="sidebar">
            <div class="sidebar-brand">
                <a href="index.php">TOKO</a>
            </div>
            <div class="sidebar-body">
                <ul>
                    <li>
                        <a href="index.php" <?= ( $page_active == 'dashboard' ) ? 'class="active"' : ''; ?>><i class="bi bi-grid me-1"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="category.php" <?= ( $page_active == 'kategori' ) ? 'class="active"' : ''; ?>><i class="bi bi-list-ul me-1"></i>Kategori</a>
                    </li>
                    <li>
                        <a href="product.php" <?= ( $page_active == 'produk' ) ? 'class="active"' : ''; ?>><i class="bi bi-list-ul me-1"></i>Produk</a>
                    </li>
                    <li>
                        <a href="product-stock-in.php" <?= ( $page_active == 'stock-in' ) ? 'class="active"' : ''; ?>><i class="bi bi-list-ul me-1"></i>Stock Masuk</a>
                    </li>
                </ul>
            </div>
        </aside>

        <!-- main content -->
        <main class="main-content">
            
            <!-- header -->
            <header class="header">
                <div class="container-fluid d-flex justify-content-between align-items-center">
                    <a href="#" class="btn-toggle">
                        <i class="bi bi-list"></i>
                    </a>
                    <div class="dropdown">
                        <a class="dropdown-toggle text-light" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person me-1"></i>Username
                        </a>

                        <ul class="dropdown-menu shadow-sm">
                            <li><a class="dropdown-item" href="#">Profile</a></li>
                            <li><a class="dropdown-item" href="#">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </header>
            <!-- end header -->

            <div class="container-fluid">
                <!-- page header -->
                <section class="page-header">
                    <h1><?= $page_title; ?></h1>
                </section>
                <!-- end page header -->