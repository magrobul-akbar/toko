<?php 
require_once __DIR__ . '/admin.php';

if( $post_type != 'product' ) {
    header('location: product.php');
    exit;
}

if( $act != 'edit' ) {
    header('location: product.php');
    exit;
}

if( ! isset( $_GET['id'] ) ) {
    header('location: product.php');
    exit;
}

if( empty( $_GET['id'] ) ) {
    header('location: product.php');
    exit;
}

if( is_null( $product ) ) {
    header('location: product.php');
    exit;
}

$product_category = [];
if( count( $product_categories ) ) {
    foreach( $product_categories as $category ) {
        $product_category[] = $category->category_id;
    }
}

$page_title = 'Edit Produk';
$page_active = 'produk';
require_once __DIR__ . '/header.php';
?>
<!-- content -->
<section class="content">

    <div class="row g-3">

        <!-- form product -->
        <div class="col-lg-8">
            
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <form action="product-edit.php?post_type=product&act=edit&id=<?= $product->id; ?>" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= $product->name; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Harga</label>
                            <input type="number" class="form-control" id="price" name="price" value="<?= $product->price; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="products_categories" class="form-label">Kategori</label>
                            <select name="products_categories[]" id="products_categories" class="form-select" multiple required>
                                <?php 
                                    foreach( $categories as $category ) :
                                ?>
                                <option value="<?= $category->id; ?>" <?= ( in_array( $category->id, $product_category ) ) ? 'selected' : ''; ?>><?= $category->name; ?></option>
                                <?php 
                                    endforeach;
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Deskripsi</label>
                            <textarea name="description" id="description" rows="3" class="form-control"><?= $product->description; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Gambar</label>
                            <img src="../assets/uploads/<?= $product->image; ?>" alt="<?= $product->name; ?>" class="img-thumbnail d-block mb-2" width="100">
                            <input type="file" class="form-control" id="image" name="image">
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm" name="save">Simpan</button>
                    </form>
                </div>
            </div>
            <!-- end form product -->
        </div>

    </div>

</section>
<!-- end content -->   
<?php 
require_once __DIR__ . '/footer.php';
?>