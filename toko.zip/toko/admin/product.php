<?php 
require_once __DIR__ . '/admin.php';

$pageTitle = 'Produk';
$pageActive = 'produk';
require_once __DIR__ . '/header.php';
?>
<!-- content -->
<section class="content">

    <div class="row g-3">

        <!-- table product -->
        <div class="col-lg-12">
            <a href="product-create.php" class="btn btn-primary btn-sm mb-3">Tambah Produk</a>
            <div class="card border-0 rounded-0 shadow-sm">
                <div class="card-body border-start border-5 border-primary">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Harga</th>
                                    <th scope="col">Jumlah</th>
                                    <th scope="col">Deskripsi</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                if( count( $products ) ) :
                                    foreach( $products as $product ) :
                                ?>
                                <tr>
                                    <td><?= $product->name; ?></td>
                                    <td>Rp. <?= number_format( $product->price, 0, ',', '.'); ?></td>
                                    <td><?= number_format( $product->stock, 0, ',', '.'); ?></td>
                                    <td><?= $product->description; ?></td>
                                    <td>
                                        <?php 
                                        if( $post_type == 'product' && $act == 'edit' ) :
                                        ?>
                                        <a href="product.php" class="btn btn-warning btn-sm">
                                            <i class="bi bi-x me-1"></i>Cancel
                                        </a>
                                            

                                        <?php 
                                        else :
                                        ?>
                                        <a href="product.php?post_type=product&act=edit&id=<?= $product->id; ?>" class="btn btn-warning btn-sm">
                                            <i class="bi bi-pencil me-1"></i>Edit
                                        </a>
                                        <form action="product.php?post_type=product" method="POST" class="d-inline-block">
                                            <input type="hidden" name="category_id" value="<?= $product->id; ?>">
                                            <button type="submit" name="delete" class="btn btn-danger btn-sm" onclick="return confirm('Kategori <?= $product->name; ?> akan dihapus!')">
                                                <i class="bi bi-trash me-1"></i>Hapus
                                            </button>
                                        </form>
                                        <?php 
                                        endif;
                                        ?>
                                    </td>
                                </tr>
                                <?php 
                                    endforeach;
                                else :
                                ?>
                                <tr>
                                    <td colspan="2" align="center">Kategori tidak ditemukan</td>
                                </tr>
                                <?php 
                                endif;
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- end table product -->

    </div>

</section>
<!-- end content -->   
<?php 
require_once __DIR__ . '/footer.php';
?>