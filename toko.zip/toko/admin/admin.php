<?php 

require_once '../config.php';

$post_type = ( isset( $_GET['post_type'] ) && ! empty( $_GET['post_type'] ) ) ? $_GET['post_type'] : null;
$act = isset( $_GET['act'] ) ? $_GET['act'] : null;

$categories = get_results("SELECT * FROM categories ORDER BY name ASC");
$products = get_results("SELECT * FROM products ORDER BY name ASC");

if( $post_type == 'category' ) {
    // get data category by id
    if( $act == 'edit' ) {
        $category_id = $_GET['id'];
        $categories = get_results("SELECT * FROM categories WHERE id = $category_id");
        $category = get_first_row("SELECT * FROM categories WHERE id = $category_id");
    }

    // save category
    if( isset( $_POST['save'] ) ) {
        $name = $_POST['name'];

        if( query("SELECT name FROM categories WHERE name = '$name'")->num_rows ) {
            header('location: category.php');
            exit;
        }
        
        $data = [
            'name' => htmlspecialchars( $name )
        ];

        if( $act == 'create' ) {
            insert_data('categories', $data);
        } else if( $act == 'edit' ) {
            update_data('categories', $data, "id = $category->id");
        }

        header('location: category.php');
        exit;
    }

    // delete category
    if( isset( $_POST['delete'] ) ) {
        $category_id = $_POST['category_id'];
        query("DELETE FROM categories WHERE id = $category_id");
        header('location: category.php');
        exit;
    }
}

if( $post_type == 'product' ) {
    if( isset( $_POST['save'] ) ) {
        $name = htmlspecialchars( $_POST['name'] );
        $price = htmlspecialchars( $_POST['price'] );
        $products_categories = $_POST['products_categories'];
        $description = htmlspecialchars( $_POST['description'] );
        $image = $_FILES['image'];

        if( query("SELECT name FROM products WHERE name = '$name'")->num_rows ) {
            header('location: product.php');
            exit;
        }

        $valid_image_extension = ['jpg', 'jpeg', 'png'];
        $image_extension = explode( '.', $image['name'] );
        $image_extension = end( $image_extension );

        if( ! in_array( $image_extension, $valid_image_extension ) ) {
            echo "<script>
                alert('Format gambar tidak valid!');
                location.href = 'product-create.php';
            </script>";
            exit;
        }

        $upload_directory = '../assets/upload';

        if( ! file_exists( $upload_directory ) ) {
            mkdir( $upload_directory );
        }

        $image_name = 'img-' . time() . '.' . $image_extension;
        move_uploaded_file( $image['tmp_name'], $upload_directory . '/' . $image_name );

        if( $act == 'create' ) {
            $db = db_connect();
            $db->query("INSERT INTO products (name, price, description, image) VALUES ('$name', '$price', '$description', '$image')");
            $product_id = $db->insert_id;

            foreach( $products_categories as $category ) {
                insert_data( 'products_categories', [
                    'product_id' => $product_id,
                    'category_id' => $category
                ]);
            }
        }

        header('location: product.php');
        exit;
    }
}