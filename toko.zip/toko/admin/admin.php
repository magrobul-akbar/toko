<?php 

require_once '../config.php';

$post_type = ( isset( $_GET['post_type'] ) && ! empty( $_GET['post_type'] ) ) ? $_GET['post_type'] : null;
$act = isset( $_GET['act'] ) ? $_GET['act'] : null;

$categories = get_results("SELECT * FROM categories ORDER BY name ASC");
$products = get_results("SELECT * FROM products ORDER BY name ASC");
$products_stock_in = get_results("SELECT products_stock_in.*, name
                                FROM products_stock_in
                                LEFT JOIN products ON products.id = products_stock_in.product_id
                                ORDER BY name ASC");

// category
if( $post_type == 'category' ) {
    // get data category by id
    if( $act == 'edit' && isset( $_GET['id'] ) ) {
        $category_id = $_GET['id'];
        $categories = get_results("SELECT * FROM categories WHERE id = '$category_id'");
        $category = get_first_row("SELECT * FROM categories WHERE id = '$category_id'");
    }

    // save category
    if( isset( $_POST['save'] ) ) {
        $name = $_POST['name'];

        if( query("SELECT name FROM categories WHERE name = '$name'")->num_rows ) {
            header('location: category.php');
            exit;
        }
        
        $data = [
            'name' => htmlspecialchars( $name )
        ];

        if( $act == 'create' ) {
            insert_data('categories', $data);
        } else if( $act == 'edit' ) {
            update_data('categories', $data, "id = $category->id");
        }

        header('location: category.php');
        exit;
    }

    // delete category
    if( isset( $_POST['delete'] ) ) {
        $category_id = $_POST['category_id'];
        query("DELETE FROM categories WHERE id = $category_id");
        header('location: category.php');
        exit;
    }
}

// product
if( $post_type == 'product' ) {
    // get data product by id
    if( $act == 'edit' && isset( $_GET['id'] ) ) {
        $product_id = $_GET['id'];
        $product = get_first_row("SELECT * FROM products WHERE id = '$product_id'");
        $product_categories = get_results("SELECT category_id FROM products_categories WHERE product_id = '$product_id'");
    }

    // save product
    if( isset( $_POST['save'] ) ) {
        $name = htmlspecialchars( $_POST['name'] );
        $price = htmlspecialchars( $_POST['price'] );
        $products_categories = $_POST['products_categories'];
        $description = htmlspecialchars( $_POST['description'] );
        $image = $_FILES['image'];

        if( $act == 'edit' ) {
            if( query("SELECT name FROM products WHERE id != '$product_id' AND name = '$name'")->num_rows ) {
                header('location: product.php');
                exit;
            }
        } else {
            if( query("SELECT name FROM products WHERE name = '$name'")->num_rows ) {
                header('location: product.php');
                exit;
            }
        }
        

        $upload_directory = '../assets/uploads';

        if( ! file_exists( $upload_directory ) ) {
            mkdir( $upload_directory );
        }

        if( $image['error'] === 0 ) {

            $valid_image_extension = ['jpg', 'jpeg', 'png'];
            $image_extension = explode( '.', $image['name'] );
            $image_extension = end( $image_extension );

            if( ! in_array( $image_extension, $valid_image_extension ) ) {

                if( $act == 'edit' ) {
                    echo "<script>
                        alert('Format gambar tidak valid!');
                        location.href = 'product-edit.php?post_type=product&act=edit&id=$product->id';
                    </script>";
                    exit;
                } else {
                    echo "<script>
                        alert('Format gambar tidak valid!');
                        location.href = 'product-create.php';
                    </script>";
                    exit;
                }
    
            }

            // hapus gambar lama.
            if( $act == 'edit' ) {
                if(  $product->image && file_exists( $upload_directory . '/' . $product->image ) ) {
                    unlink( $upload_directory . '/' . $product->image );
                }
            }

            $image_name = 'img-' . time() . '.' . $image_extension;
            move_uploaded_file( $image['tmp_name'], $upload_directory . '/' . $image_name );
        } else {
            if( $act == 'edit' ) {
                $image_name = $product->image;
            } else {
                $image_name = null;
            }
        }

        $db = db_connect();
        if( $act == 'create' ) {
            $db->query("INSERT INTO products (name, price, description, image) VALUES ('$name', '$price', '$description', '$image_name')");
            $product_id = $db->insert_id;

            foreach( $products_categories as $category ) {
                insert_data( 'products_categories', [
                    'product_id' => $product_id,
                    'category_id' => $category
                ]);
            }
        } else if( $act == 'edit' ) {
            $db->query("UPDATE products SET name = '$name', price = '$price', description = '$description', image = '$image_name' WHERE id = '$product_id'");

            $db->query("DELETE FROM products_categories WHERE product_id = '$product_id'");

            foreach( $products_categories as $category ) {
                insert_data( 'products_categories', [
                    'product_id' => $product_id,
                    'category_id' => $category
                ]);
            }
        }

        header('location: product.php');
        exit;
    }

    // delete product
    if( isset( $_POST['delete'] ) ) {
        $product_id = $_POST['product_id'];
        query("DELETE FROM products WHERE id = '$product_id'");
        header('location: product.php');
        exit;
    }
}

// product stock in
if( $post_type == 'product-stock-in' ) {
    // save product stock in
    if( isset( $_POST['save'] ) ) {
        $product_id = $_POST['product_id'];
        $stock = $_POST['stock'];
        $date_of_entry = $_POST['date_of_entry'];

        if( $act == 'create' ) {
            insert_data('products_stock_in', [
                'product_id' => $product_id,
                'stock' => $stock,
                'date_of_entry' => $date_of_entry
            ]);

            $product = get_first_row("SELECT stock FROM products WHERE id = '$product_id'");

            update_data('products', [
                'stock' => ( $product->stock + $stock )
            ], "id = '$product_id'");
        }
        
        header('location: product-stock-in.php');
        exit;
    }

    // delete stock product int
    if( isset( $_POST['delete'] ) ) {
        $product_stock_in_id = $_POST['product_stock_in_id'];
        $product_stock_in = get_first_row("SELECT * FROM products_stock_in WHERE id = '$product_stock_in_id'");
        $product = get_first_row("SELECT * FROM products WHERE id = '$product_stock_in->product_id'");

        update_data('products', [
            'stock' => ( $product->stock - $product_stock_in->stock )
        ], "id = '$product->id'");
        query("DELETE FROM products_stock_in WHERE id = '$product_stock_in_id'");
        header('location: product-stock-in.php');
        exit;
    }
}