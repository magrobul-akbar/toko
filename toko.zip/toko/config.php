<?php 

// base url
if( ! defined('BASE_URL') ) {
    define('BASE_URL', 'http://localhost/toko');
}

// database mysql
if( ! defined('DB_NAME') ) {
    define('DB_NAME', 'db_alshop');
}

if( ! defined('DB_HOST') ) {
    define('DB_HOST', 'localhost');
}

if( ! defined('DB_USER') ) {
    define('DB_USER', 'root');
}

if( ! defined('DB_PASS') ) {
    define('DB_PASS', '');
}

// $con = new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );

if( ! function_exists('db_connect') ) {
    /**
     * Connect to database
     */
    function db_connect() {
        return new mysqli( DB_HOST, DB_USER, DB_PASS, DB_NAME );
    }
}

if( ! function_exists('query') ) {
    /**
     * Send query to database
     */
    function query( string $query ) {
        return db_connect()->query( $query );
    }
}

if( ! function_exists('get_results') ) {
    /**
     * Return results data from database
     */
    function get_results( string $query ) {
        $db = query( $query );
        $rows = [];

        while( $row = $db->fetch_object() ) {
            $rows[] = $row;
        }

        return $rows;
    }
}

if( ! function_exists('get_first_row') ) {
    /**
     * Return first rows data in object from database
     */
    function get_first_row( string $query ) {
        return query( $query )->fetch_object();
    }
}

if( ! function_exists('insert_data') ) {
    /**
     * Insert data to database
     */
    function insert_data( string $table, array $data ) {
       $keys = array_keys( $data );
       $values = array_values( $data );
       $fields = implode( ',', $keys );

       for( $i = 0; $i < count( $keys ); $i++ ) {
        if( is_string( $values[ $i ] ) ) {
            $fields_values[] = "'$values[$i]'";
        } else {
            $fields_values[] = $values[ $i ];
        }
       }

       $values = implode( ',', $fields_values );
       $insert = query("INSERT INTO $table ($fields) VALUES ($values)");

       if( $insert ) {
        return true;
       }

       die( db_connect()->error );
    }
}

if( ! function_exists('update_data') ) {
    /**
     * update data to database
     */
    function update_data( string $table, array $data, string $condition ) {
       $keys = array_keys( $data );
       $values = array_values( $data );

       for( $i = 0; $i < count( $keys ); $i++ ) {
        if( is_string( $values[ $i ] ) ) {
            $set[] = $keys[$i] . " = '$values[$i]'";
        } else {
            $set[] = $keys[$i] . ' = ' . $values[ $i ];
        }
       }

       $values = implode( ',', $set );
       $update = query("UPDATE $table SET $values WHERE $condition");

       if( $update ) {
        return true;
       }

       die( db_connect()->error );
    }
}

if( ! function_exists('product_categories') ) {
    /**
     * Return product categories in product id
    */
    function product_categories( $product_id ) {
        return get_results("SELECT categories.* FROM products_categories
                            LEFT JOIN categories ON categories.id = products_categories.category_id
                            WHERE product_id = '$product_id'
                            ORDER BY name ASC");
    }
}